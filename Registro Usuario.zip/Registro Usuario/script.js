const BotonRegistro = document.getElementById('Registrate');
const BotonInicio = document.getElementById('Iniciasesion');
const contenedor = document.getElementById('contenedor');

BotonRegistro.addEventListener('click', () => {
	contenedor.classList.add("panel-derecho-activado");
});
BotonInicio.addEventListener('click', () => {
	contenedor.classList.remove("panel-derecho-activado");
});